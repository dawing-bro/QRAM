const { exec } = require('child_process');

const QRAM_PATH = '/QRAM';
const TOTAL_CAPACITY = 34; // Твои 34 МБ

function getQramStatus() {
    // Команда du -sm покажет размер папки в мегабайтах
    exec(`du -sm ${QRAM_PATH}`, (error, stdout) => {
        if (error) {
            console.log("Ошибка: Возможно, папка /QRAM не создана или нет прав.");
            return;
        }

        const usedMB = parseInt(stdout.split('\t')[0]);
        const freeMB = TOTAL_CAPACITY - usedMB;
        const usagePercent = ((usedMB / TOTAL_CAPACITY) * 100).toFixed(2);

        console.clear();
        console.log(`--- Монитор QRAM (Founder Mode) ---`);
        console.log(`Занято: ${usedMB} МБ из ${TOTAL_CAPACITY} МБ`);
        console.log(`Свободно: ${freeMB} МБ`);
        console.log(`Нагрузка: ${usagePercent}%`);
    });
}

// Проверка каждую секунду
setInterval(getQramStatus, 1000);

