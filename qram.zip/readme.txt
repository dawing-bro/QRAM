Чтобы установить QRAM вам нужно:

       1. Создать в корне раздела папку QRAM
       2. Создать раздел на диске от 10 до 60 МБ
       3. Скопировать файлы из этого архива в папку QRAM
       4. Введите lsblk в терминале
       5. Отмонтируйте раздел который создали
       6. Введите в терминале sudo mount /dev/sdaX /QRAM или sudo mount /dev/nvmeXnXpX (где X номер диска или раздела) также бывают вариаций типа /dev/sdb, /dev/sdc, /dev/sdd и т. д.

To install QRAM, you need to:

       1. Create a folder named QRAM in the root directory.
       2. Create a disk partition between 10 and 60 MB.
       3. Copy the files from this archive into the QRAM folder.
       4. Type lsblk in the terminal.
       5. Unmount the partition you created.
       6. Type sudo mount /dev/sdaX /QRAM or sudo mount /dev/nvmeXnXpX /QRAM in the terminal (where X is the disk or partition number). There may also be variations like /dev/sdb, /dev/sdc, /dev/sdd, etc.

Um QRAM zu installieren, müssen Sie Folgendes tun:

       1. Erstellen Sie im Stammverzeichnis (Root) den Ordner QRAM.
       2. Erstellen Sie eine Partition auf der Festplatte mit einer Größe von 10 bis 60 MB.
       3. Kopieren Sie die Dateien aus diesem Archiv in den Ordner QRAM.
       4. Geben Sie lsblk im Terminal ein.
       5. Hängen Sie die erstellte Partition aus (Unmount).
       6. Geben Sie im Terminal sudo mount /dev/sdaX /QRAM oder sudo mount /dev/nvmeXnXpX /QRAM ein (wobei X für die Nummer des Laufwerks oder der Partition steht). Es gibt auch Variationen wie /dev/sdb, /dev/sdc, /dev/sdd usw.
